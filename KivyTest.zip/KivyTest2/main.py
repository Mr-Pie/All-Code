import kivy
kivy.require('1.10.0')
from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button


class HomeScreen(GridLayout):
    def hello(integer):
        print('Hello')
    

class MyApp(App):

    def build(self):
        return HomeScreen()
    

if __name__ == '__main__':
    MyApp().run()
