from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
import socket


TCP_IP = '192.168.0.3'
TCP_PORT = 29200

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((TCP_IP, TCP_PORT))

class HomeScreen(GridLayout):
    def __init__(self, **kwargs):
        super(HomeScreen, self).__init__(**kwargs)

        def btn1(junk):
            MESSAGE = b'button1\n'
            s.send(MESSAGE)
            return
        
        def btn2(junk):
            MESSAGE = b'button2\n'
            s.send(MESSAGE)
            return

        def btn3(junk):
            MESSAGE = b'button3\n'
            s.send(MESSAGE)
            return

        def btn4(junk):
            MESSAGE = b'button4\n'
            s.send(MESSAGE)
            return
        
        self.cols = 2
        btn1 = Button(text='btn1', font_size=30,on_press=btn1)
        btn2 = Button(text='btn2', font_size=30,on_press=btn2)
        btn3 = Button(text='btn3', font_size=30,on_press=btn3)
        btn4 = Button(text='btn4', font_size=30,on_press=btn4)
        self.add_widget(btn1)
        self.add_widget(btn2)
        self.add_widget(btn3)
        self.add_widget(btn4)
        
class MyApp(App):

    def build(self):
        return HomeScreen()
    

if __name__ == '__main__':
    MyApp().run()
