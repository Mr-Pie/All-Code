﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace PieChat
{
    public class ExtraThread
    {
        public static void ReceiveMessages()
        {
            string serverIP = "192.168.0.33";
            Int32 port = 8000;
            TcpClient client = new TcpClient(serverIP, port);
            // NetworkStream netstream = default(NetworkStream);
            NetworkStream netstreamin = client.GetStream();

            while (true)
            {
                //Console.WriteLine("Working thread...");
                 byte[] bytesToRead = new byte[client.ReceiveBufferSize];
                 int bytesRead = netstreamin.Read(bytesToRead, 0, client.ReceiveBufferSize);
                string messagegot = Encoding.ASCII.GetString(bytesToRead, 0, bytesRead);
                 Console.WriteLine("Received : " + messagegot);
                Thread.Sleep(500);
            }
        }
    }

    class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Console.WriteLine("Starting code1\n");
            Thread thread1 = new Thread(ExtraThread.ReceiveMessages);
            thread1.Start();
            Application.Run(new Form1());
            
            //Console.WriteLine("Starting code2\n");
            
        }
    }
}
