﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace PieChat
{
    public partial class Form1 : Form
    {
        string serverIP = "192.168.0.8";
        Int32 port = 8000;
        TcpClient client = new TcpClient();
        string message;
        string readData = null;
        NetworkStream netstream = default(NetworkStream);
        public Form1()
        {
            InitializeComponent();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            message = textBox1.Text;
            Console.WriteLine(message);
            
        }

        private void connect_Click(object sender, EventArgs e)
        {
            client.ConnectAsync(serverIP, port);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void send_Click(object sender, EventArgs e)
        {
            NetworkStream netstream = client.GetStream();
            ASCIIEncoding asen = new ASCIIEncoding();
            message = message + "\n";
            byte[] ba = asen.GetBytes(message);
            netstream.Write(ba, 0, ba.Length);
            textBox1.Text = "";
        }
        private void ReceiveMessage()
        {
            while(true)
            {
                NetworkStream netstreamin = client.GetStream();
                int buffSize = 0;
                byte[] inStream = new byte[10025];
                buffSize = client.ReceiveBufferSize;
                netstreamin.Read(inStream, 0, buffSize);
                string returndata = System.Text.Encoding.ASCII.GetString(inStream);
                Console.WriteLine(returndata);
                    
                readData = returndata;
            }
        }
        private void Message()
        {
            //textBox2.Text = readData;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        { 
           // textBox2.Text = readData;
        }

    }

}
