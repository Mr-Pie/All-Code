﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Timers;

namespace PieChat
{
    public partial class Form1 : Form
    {
        public string serverIP = "192.168.33.41";
        public Int32 port = 8000;
        public TcpClient client = new TcpClient();
        public string message;
        public string readData = null;
        public NetworkStream netstream;
        public static System.Timers.Timer aTimer;

     
        public void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            ASCIIEncoding encoder = new ASCIIEncoding();
            int bytesRead = 0;
            byte[] message = new byte[4096];
            bytesRead = netstream.Read(message, 0, 4096);
            string respMsg = encoder.GetString(message, 0, bytesRead);

            readData = respMsg;
            Console.WriteLine("received {0}\n", respMsg);
            Message();
        }
        public void SetTimer()
        {
            // Create a timer with a two second interval.
            aTimer = new System.Timers.Timer(2000);
            // Hook up the Elapsed event for the timer. 
            aTimer.Elapsed += OnTimedEvent;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
        }

        public Form1()
        {
            client.ConnectAsync(serverIP, port);
            InitializeComponent();
            textBox2.ReadOnly = true;
            textBox2.BackColor = System.Drawing.SystemColors.Window;
            netstream = client.GetStream();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            message = textBox1.Text;
            Console.WriteLine(message);
            
        }

        private void connect_Click(object sender, EventArgs e)
        {
           // client.ConnectAsync(serverIP, port);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void send_Click(object sender, EventArgs e)
        {
           // netstream = client.GetStream();
            ASCIIEncoding asen = new ASCIIEncoding();
            message = message + "\n";
            byte[] ba = asen.GetBytes(message);
            netstream.Write(ba, 0, ba.Length);
            textBox1.Text = "";
        }
   
        private void Message()
        {
            //textBox2_TextChanged(readData);
            //textBox2.Text = readData;
        }
        
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.Text = readData;
        }

    }

}
